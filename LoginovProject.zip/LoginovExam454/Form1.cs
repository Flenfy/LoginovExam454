﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginovExam454
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LoadDataToGrid(string query, SqlParameter[] parameters = null, string tableName = "Results")
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Program.conStr))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        if (parameters != null)
                            cmd.Parameters.AddRange(parameters);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            DataTable table = new DataTable(tableName);
                            table.Load(reader);
                            table_gv.DataSource = table;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\nЗапрос:\n{query}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = @"
                SELECT dbo.Диагнозы.[Наименование диагноза], dbo.Пациенты.ФИО AS [ФИО пациента] FROM dbo.Диагнозы INNER JOIN
                dbo.Приемы ON dbo.Диагнозы.[Номер диагноза] = dbo.Приемы.[Заключение врача] INNER JOIN
                dbo.Пациенты ON dbo.Приемы.[Номер пациента] = dbo.Пациенты.[Номер больного] WHERE (dbo.Диагнозы.[Наименование диагноза] = @SupplierName)";

            SqlParameter param = new SqlParameter("@SupplierName", SqlDbType.NVarChar)
            {
                Value = textBox1.Text.Trim()
            };

            LoadDataToGrid(query, new[] { param });
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = @"
                SELECT TOP (100) PERCENT dbo.Врачи.ФИО AS [ФИО врача], COUNT(dbo.Пациенты.ФИО) AS [Количество больных] FROM dbo.Врачи INNER JOIN
                dbo.Приемы ON dbo.Врачи.[Номер врача] = dbo.Приемы.[Номер врача] INNER JOIN
                dbo.Пациенты ON dbo.Приемы.[Номер пациента] = dbo.Пациенты.[Номер больного] GROUP BY dbo.Врачи.ФИО ORDER BY [Количество больных] DESC";
            LoadDataToGrid(query);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = @"
                SELECT TOP (3) dbo.Пациенты.ФИО, COUNT(dbo.Приемы.[Номер приема]) AS [Количество посещений]
                FROM dbo.Пациенты INNER JOIN
                dbo.Приемы ON dbo.Пациенты.[Номер больного] = dbo.Приемы.[Номер пациента]
                GROUP BY dbo.Пациенты.ФИО
                ORDER BY [Количество посещений] DESC";
            LoadDataToGrid(query);
        }
    }
}
